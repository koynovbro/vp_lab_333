#ifndef DOCWINDOW_KOYNOV_H
#define DOCWINDOW_KOYNOV_H

#include <QTextEdit>
#include <QFileDialog>
#include <QTextStream>
#include <QMessageBox>
#include <QColor>
#include <QColorDialog>

class DocWindow_Koynov: public QTextEdit {
    Q_OBJECT
private:
    QString m_strFileName;
public:
    DocWindow_Koynov(QWidget* pwgt = 0);
signals:
    void changeWindowTitle(const QString&);
public slots:
    void slotLoad();
    void slotSave();
    void slotSaveAs();
    void slotColor();
};

#endif // DOCWINDOW_KOYNOV_H
