#include "docwindow_koynov.h"

DocWindow_Koynov::DocWindow_Koynov(QWidget* pwgt): QTextEdit(pwgt)
{

}

void DocWindow_Koynov::slotLoad()
{
    QString str = QFileDialog::getOpenFileName(0, 0, 0, "Текстовый документ (*.txt) ;; HTML документ (*.html)");
    if (str.isEmpty()){
        return;
    }

    QFile file_html(str + ".html");
    QFile file(str);
    if(!file_html.exists()){
        file.open(QIODevice::ReadOnly);
        QTextStream stream(&file);
        setPlainText(stream.readAll());
        file.close();
    }
    else{
        file_html.open(QIODevice::ReadOnly);
        QTextStream stream(&file_html);
        setHtml(stream.readAll());
        file_html.close();
    }

    m_strFileName = str;
    emit changeWindowTitle(m_strFileName);
}

void DocWindow_Koynov::slotSaveAs()
{
    QString str = QFileDialog::getSaveFileName(0, m_strFileName, "Новый текстовый документ", "Текстовый документ (*.txt) ;; HTML документ (*.html)");
    if (!str.isEmpty()){
        m_strFileName = str;
        slotSave();
    }
}

void DocWindow_Koynov::slotSave()
{
    if (m_strFileName.isEmpty()){
        slotSaveAs();
        return;
    }

    QFile file(m_strFileName);
    QFile file_html(m_strFileName + ".html");
    if (file.open(QIODevice::WriteOnly) && file_html.open(QIODevice::WriteOnly)){
        QTextStream(&file)<<toPlainText();
        QTextStream(&file_html)<<toHtml();

    }
    file.close();
    file_html.close();
    emit changeWindowTitle(m_strFileName);

    QMessageBox::information(this, "Результат", "Файл успешно сохранен");
}

void DocWindow_Koynov::slotColor()
{
    QColor addColor = QColorDialog::getColor();
    setTextColor(addColor);
}
