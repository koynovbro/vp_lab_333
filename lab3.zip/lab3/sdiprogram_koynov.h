#ifndef SDIPROGRAM_KOYNOV_H
#define SDIPROGRAM_KOYNOV_H

#include <QMainWindow>
#include <QtWidgets>
#include "docwindow_koynov.h"
#include "sdiprogram_koynov.h"

class SDIProgram_Koynov : public QMainWindow
{
    Q_OBJECT

public:
    SDIProgram_Koynov(QWidget *pwgt = 0): QMainWindow(pwgt)
    {
        QMenu* pmnuFile = new QMenu("&File");
        QMenu* pmnuHelp = new QMenu("&Help");
        DocWindow_Koynov* pdoc = new DocWindow_Koynov;

        pmnuFile->addAction("&Open...", pdoc, SLOT(slotLoad()), QKeySequence("CTRL+O"));
        pmnuFile->addAction("Save...", pdoc, SLOT(slotSave()), QKeySequence("CTRL+S"));
        pmnuFile->addAction("&Save As...", pdoc, SLOT(slotSaveAs()), QKeySequence("CTRL+P"));
        pmnuFile->addAction("&Color...", pdoc, SLOT(slotColor()), QKeySequence("F2"));
        pmnuFile->addAction("&Quit", qApp, SLOT(quit()));
        pmnuHelp->addAction("&About", this, SLOT(slotAbout()), QKeySequence("F1"));

        menuBar()->addMenu(pmnuFile);
        menuBar()->addMenu(pmnuHelp);


        setCentralWidget(pdoc);

        connect(pdoc, SIGNAL(changeWindowTitle(const QString&)), SLOT(slotChangeWindowTitle(const QString&)));

        statusBar()->showMessage("Ready", 2000);

    }

private:

public slots:
    void slotAbout()
    {
        QMessageBox::about(this, "Application", "Автор Койнов");
    }

    void slotChangeWindowTitle(const QString& str)
    {
        setWindowTitle(str);
    }
};

#endif // SDIPROGRAM_KOYNOV_H
